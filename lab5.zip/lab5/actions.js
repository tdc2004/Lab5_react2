// B1

// Khai bao ham (Khai báo các actions)

export const Tang = () => ({ type: 'tang' }) //Khai báo hàm tăng
export const Giam = () => ({ type: 'giam' }) // Khai báo hàm giảm